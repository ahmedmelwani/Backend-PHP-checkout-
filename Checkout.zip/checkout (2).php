
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $fullname = $data['fullname'] ?? '';
    $email = $data['email'] ?? '';
    $phone = $data['phone'] ?? '';
    $address = $data['address'] ?? '';
    $city = $data['city'] ?? '';
    $district = $data['district'] ?? '';
    $postal = $data['postal'] ?? '';
    $payment = $data['payment'] ?? '';

    if (!$fullname || !$email || !$phone || !$address || !$city || !$district || !$postal || !$payment) {
        echo json_encode(["success" => false, "message" => "Please fill in all fields."]);
        exit;
    }

    echo json_encode([
        "success" => true,
        "message" => "Order received successfully.",
        "data" => $data
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Unsupported request method."]);
}
?>
